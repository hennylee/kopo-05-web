package kr.co.hn.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.hn.dao.QNABoardDAO;
import kr.co.hn.vo.QNABoradVO;

public class QNADetailController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		int no = Integer.parseInt(request.getParameter("no"));
		
		QNABoardDAO dao = new QNABoardDAO();
		QNABoradVO vo = dao.selectByNo(no);
		
		request.setAttribute("vo", vo);
		
		return "/qna/detail.jsp";
	}

}
