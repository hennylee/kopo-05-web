-- 오픈뱅킹 정보 동의
create table open_agreement(
    -- 회원 id
    -- 동의일자
    -- 동의여부 default 'Y'
    -- 연결 계좌
);

